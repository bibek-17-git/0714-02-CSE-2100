#ifndef UTILS_H
#define UTILS_H

void update_status(const char *message, double progress);
void show_notification_msg(const char *title, const char *msg);

#endif /* UTILS_H */
